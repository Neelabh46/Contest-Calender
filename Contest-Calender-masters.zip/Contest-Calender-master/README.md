An App which lists current and upcoming contests
